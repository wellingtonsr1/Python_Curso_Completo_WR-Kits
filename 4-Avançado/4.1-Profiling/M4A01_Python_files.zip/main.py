import cProfile
import time

def funcao_demorada():
    time.sleep(0.2)

def funcao_demorada2():
    time.sleep(0.1)

def main():
    for _ in range(5):
        funcao_demorada()
        funcao_demorada2()

if __name__ == "__main__":
    #Iniciando o profiler
    profiler = cProfile.Profile() #Cria o objeto baseado no metodo Profile
    profiler.enable()  #Habilita o Profiler

    #Inicia a rotina principal do software
    main()

    profiler.disable()
    profiler.print_stats(sort='cumulative')
