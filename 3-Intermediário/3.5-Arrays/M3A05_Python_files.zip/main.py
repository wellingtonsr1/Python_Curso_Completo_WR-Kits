import array

# 'b': signed char (inteiro de 1 byte)
# 'B': unsigned char (inteiro sem sinal de 1 byte)
# 'i': signed int (inteiro de 2 bytes)
# 'I': unsigned int (inteiro sem sinal de 2 bytes)
# 'l': signed long (inteiro de 4 bytes)
# 'L': unsigned long (inteiro sem sinal de 4 bytes)

meu_array = array.array('i', [1, 2, 3])
print(meu_array)

for n in meu_array:
    print(n)

meu_array.append(20)
print(meu_array)

meu_array_float = array.array('f', [1.1, 2.2, 3.3])
print(meu_array_float)

