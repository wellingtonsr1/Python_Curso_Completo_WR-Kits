# ^: Âncora de início de linha.
# $: Âncora de final de linha.
# .: Corresponde a qualquer caractere, exceto uma nova linha.
# *: Corresponde a zero ou mais ocorrências do caractere anterior.
# +: Corresponde a uma ou mais ocorrências do caractere anterior.
# ?: Torna o caractere anterior opcional.
# \: Escape, usado para tratar caracteres especiais como literais.

import re

texto = "Python é uma das linguagens de programaçãos mais poderosas"
padrão = r'^Python'
resultado = re.search(padrão, texto)

if resultado:
    print("Encontrado", resultado.group())
else:
    print("Não encontrado")


texto = "Python é uma das linguagens de programaçãos mais poderosas"
padrão = r'poderosas$'
resultado = re.search(padrão, texto)

if resultado:
    print("Encontrado", resultado.group())
else:
    print("Não encontrado")

email = "usuar#io@exemplo.com.br"
padrao_email = r'^[a-zA-Z0-9.#_%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
resultado = re.match(padrao_email, email)

if resultado:
    print("E-mail válido")
else:
    print("E-mail invalido")

texto = "Telefone de contato: (11) 123-123-123"
padrao_telefone = r'\(\d{2}\) \d{3}-\d{3}-\d{3}'
resultado = re.search(padrao_telefone, texto)

if resultado:
    print("Numero encontrado", resultado.group())
else:
    print("Numero não encontrado")
