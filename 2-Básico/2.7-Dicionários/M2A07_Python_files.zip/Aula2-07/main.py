info = {
    'nome': 'Zeze',
    'idade': 30,
    'cidade': "Porto Alegre"
}

print(info)
print(info['nome'])



removido = info.pop('cidade')
print("removido: ", removido, info)

del info['idade']
print(info)

info['pais'] = 'Brasil'
print(info)

info['pais'] = 'Canada'
print(info)

info['nome'] = ["Zeze", "João"]
var = info['nome']
var.append("Josias")
info['nome'] = var
print(info['nome'])

info['nome'].append('Valor')
print(info['nome'][0].upper())

info.clear()
print(info)

del info
info = {
    'altura': 1.8,
}

print(info)
if info.get('peso', 'sem valor') == 'sem valor':
    info['peso'] = int(input("Valor ão definido - Digite peso: "))
    print(info['peso'])
else:
    print(info['peso'])
