import string
import sys

intVal = 42
floatVal = 3.14
boolVal = False
charVar = 'A'
stringVar = "Hello World"


print(sys.getsizeof(stringVar))



