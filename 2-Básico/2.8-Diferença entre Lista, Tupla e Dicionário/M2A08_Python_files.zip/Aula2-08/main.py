lista = [1,2,3,4,5, [0,1,'Valor',3]]
print(lista)

tupla = (1,2,3,4, ('Valor1', 'Valor2'))
print(tupla)

dicionario = {
    'nome' : 511422142
}
print(dicionario)
