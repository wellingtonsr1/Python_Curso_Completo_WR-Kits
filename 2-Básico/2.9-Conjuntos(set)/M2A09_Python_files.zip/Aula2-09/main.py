
frutas1 = {'maça', 'banana', 'uva', 'laranja'}
frutas2 = {'uva', 'pêssego', 'abacaxi', 'pera', 'laranja'}

print(frutas1)
frutas1.add('morango')
print(frutas1)

frutas1.add('maça')
print(frutas1)

frutas1.remove('morango')
print(frutas1)

uniao = frutas1.union(frutas2)
print(uniao)

intersecao = frutas1.intersection(frutas2)
print(intersecao)

diferenca = frutas1.difference(frutas2)
print(diferenca)

diferenca = frutas2.difference(frutas1)
print(diferenca)

tem_morango = 'morango' not in frutas1
print('Não tem morando? ', tem_morango)

print('Frutas 2 é subconjunto de frutas 1? ', frutas2.issubset(frutas1))
print('Frutas 1 é subconjunto de uniao? ', frutas1.issubset(uniao))
