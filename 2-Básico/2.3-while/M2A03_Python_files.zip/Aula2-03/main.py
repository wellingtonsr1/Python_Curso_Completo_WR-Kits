import random

numero_sorteado = random.randint(1,100)

chute = 0
print("Jogo de adivinhacao - adivinhe um numero entre 1 e 100")

while numero_sorteado != chute:
    chute = int(input("Adivinhe o numero: "))

    if chute < numero_sorteado:
        print("Seu numero é MENOR do numero sorteado - Tente novamente")
    elif chute > numero_sorteado:
        print("Seu numero é MAIOR do numero sorteado - Tente novamente")
    else:
        print("Parabens! Você acertou o número: " + str(chute))
        break
