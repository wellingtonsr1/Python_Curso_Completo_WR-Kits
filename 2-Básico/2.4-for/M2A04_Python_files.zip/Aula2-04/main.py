myString = "Hello World"

for letter in myString:
    print(letter)
