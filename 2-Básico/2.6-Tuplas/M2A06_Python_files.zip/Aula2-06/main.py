#tupla / tuple
tupla = (1,2,3,4,(3,4))

print(tupla)
print("Acessando o elemento index 2:", tupla[2])
print("Acessando o ultimo elemento da tupla:", tupla[-1])
print("Slicing - retornando elementos 2 - 5:", tupla[2:5])

print("Valor 3 está na tupla? ", 3 in tupla)
print("Valor 3 está na tupla? ", 3 not in tupla)

var = [ 1, 2, 3 ]
var.append(10)
var.extend([20,30,40])
print(var)
var = tuple(var)
print(var)
